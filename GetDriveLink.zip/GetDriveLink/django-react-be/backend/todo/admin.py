from django.contrib import admin

from .models import Files

class FilesAdmin(admin.ModelAdmin):
    list_display = ('file',)

# Register your models here.

admin.site.register(Files, FilesAdmin)