from rest_framework.views import APIView
from rest_framework.response import Response
import subprocess
from django.http import JsonResponse
from rest_framework import viewsets
from .models import Files
from .serializers import FilesSerializer
import os

# Create your views here.

class FilesViewSet(viewsets.ModelViewSet):
    queryset = Files.objects.all()
    serializer_class = FilesSerializer

class MyView(APIView):
    def post(self, request, format=None):
        # Access the data sent in the request
        data = request.data.get("data")
        result = subprocess.run(['python', 'todo/script_need_run.py', data], capture_output=True)
        output = result.stdout.decode('utf-8')
        output = output.strip()
        return JsonResponse({'output': output})
    
class DeleteView(APIView):
    def post(self, request, format=None):
        data = request.data.get("data")
        os.remove(data)
        return JsonResponse({'output': "Success"})