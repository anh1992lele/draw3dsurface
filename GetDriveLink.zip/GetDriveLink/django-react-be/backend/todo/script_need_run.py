import sys
import requests
import random
import string
import sys
import mimetypes

link = str(sys.argv[1])
file_id = link.split('/d/')[1].split('/')[0]

requests_link = 'https://www.googleapis.com/drive/v3/files/' + str(file_id) + '?alt=media&key=AIzaSyAA9ERw-9LZVEohRYtCWka_TQc6oXmvcVU'

response = requests.get(requests_link)
content_type = response.headers['content-type']
extension = mimetypes.guess_extension(content_type)

if (extension == None):
    exit()

def generate_random_filename(length):
    letters_digits = string.ascii_letters + string.digits
    return ''.join(random.choices(letters_digits, k=length)) + extension

filename = generate_random_filename(32)

file_path = "media/store/files/" + filename

CHUNK_SIZE = 32768
with open(file_path, "wb") as f:
    for chunk in response.iter_content(CHUNK_SIZE):
        if chunk:  # filter out keep-alive new chunks
            f.write(chunk)

print(file_path)